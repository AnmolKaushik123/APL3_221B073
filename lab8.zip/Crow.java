public interface Crow{
    public abstract void cry();
    public abstract void fly();
    public abstract void eat();
    
}