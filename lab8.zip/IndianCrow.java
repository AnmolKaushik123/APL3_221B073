public class IndianCrow implements Crow{
    public void cry(){
         System.out.println("Cawing");
    }
    public void fly(){
         System.out.println("Flying high over the mopuntain ");
    }
    public void eat(){
         System.out.println("eating pearls");
    }
}